# BaseSerialPortTool
Base serial port tool template code.

https://blog.csdn.net/sishuihuahua/article/details/84556901
